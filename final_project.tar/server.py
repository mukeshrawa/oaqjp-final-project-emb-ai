"""Flask application for emotion detection."""
from flask import Flask, render_template, request
from EmotionDetection.emotion_detection import emotion_detector

app = Flask(__name__)

@app.route("/")
def render_index_page():
    """Render the application's home page."""
    return render_template("index.html")

@app.route("/emotionDetector", methods=["GET"])
def emt_detect():
    """Analyze the input text and return emotion scores."""
    text_to_analyze = request.args.get("textToAnalyze")
    response = emotion_detector(text_to_analyze)
    dominant_emotion = response['dominant_emotion']

    if dominant_emotion is None:
        return " Invalid text! Please try again!."

    return response


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
   